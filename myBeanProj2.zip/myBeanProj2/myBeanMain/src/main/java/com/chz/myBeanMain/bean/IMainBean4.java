package com.chz.myBeanMain.bean;

public interface IMainBean4
{
    String getName();
}
